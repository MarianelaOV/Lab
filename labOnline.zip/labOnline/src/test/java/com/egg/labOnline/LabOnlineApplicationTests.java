package com.egg.labOnline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
