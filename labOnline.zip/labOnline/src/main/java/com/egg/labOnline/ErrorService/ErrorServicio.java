package com.egg.labOnline.ErrorService;

public class ErrorServicio extends Exception {
	
	public ErrorServicio(String msj) {
		super(msj);
	}

}
